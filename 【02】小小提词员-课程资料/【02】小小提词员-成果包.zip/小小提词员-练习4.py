'''小小提词员-阶段3'''

#调用time库
import time

#等待秒数
i = 2

#提词器
print('己亥杂诗（其五）')
time.sleep(i)
print('浩荡', end='', flush=True)
time.sleep(i)
print('离愁', end='', flush=True)
time.sleep(i)
print('白日斜,', end='', flush=True)
time.sleep(i)
print('吟鞭', end='', flush=True)
time.sleep(i)
print('东指', end='', flush=True)
time.sleep(i)
print('即天涯。', flush=True)
time.sleep(i)
print('落红', end='', flush=True)
time.sleep(i)
print('不是', end='', flush=True)
time.sleep(i)
print('无情物,', end='', flush=True)
time.sleep(i)
print('化作', end='', flush=True)
time.sleep(i)
print('春泥', end='', flush=True)
time.sleep(i)
print('更护花。')
