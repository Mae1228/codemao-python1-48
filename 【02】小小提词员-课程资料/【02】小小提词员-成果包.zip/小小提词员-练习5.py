'''loading......动态加载'''
#调用time库
import time

#等待秒数
i = 1

#loading......
print('loading',end='',flush=True)
time.sleep(i)
print('.', end='', flush=True)
time.sleep(i)
print('.', end='', flush=True)
time.sleep(i)
print('.', end='', flush=True)
time.sleep(i)
print('.', end='', flush=True)
time.sleep(i)
print('.', end='', flush=True)
time.sleep(i)
print('.')
