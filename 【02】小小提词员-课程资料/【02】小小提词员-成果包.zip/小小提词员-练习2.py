'''小小提词员-阶段2'''
#调用time库
import time

#等待秒数
i = 2

#提词器
print('己亥杂诗（其五）')
time.sleep(i)
print('浩荡')
time.sleep(i)
print('离愁')
time.sleep(i)
print('白日斜,')
time.sleep(i)
print('吟鞭')
time.sleep(i)
print('东指')
time.sleep(i)
print('即天涯。')
time.sleep(i)
print('落红')
time.sleep(i)
print('不是')
time.sleep(i)
print('无情物,')
time.sleep(i)
print('化作')
time.sleep(i)
print('春泥')
time.sleep(i)
print('更护花。')
